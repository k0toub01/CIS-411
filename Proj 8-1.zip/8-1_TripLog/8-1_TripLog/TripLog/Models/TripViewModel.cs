﻿namespace TripLog.Models
{
    public class TripViewModel
    {
        public Trip Trip { get; set; }
        public int PageNumber { get; set; }
    }
}
