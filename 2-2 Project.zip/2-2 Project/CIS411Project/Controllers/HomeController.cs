﻿using CIS411Project.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CIS411Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewBag.FV = 0;
            return View();
        }

        [HttpGet]
        public IActionResult TipCalc()
        {
            ViewBag.FV = 0;
            ViewBag.FV1 = 0;
            ViewBag.FV2 = 0;
            return View();
        }
        [HttpPost]
        public IActionResult TipCalc(TipCalcModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.FV = model.discount15();
                ViewBag.FV1 = model.discount20();
                ViewBag.FV2 = model.discount25();
            }
            else
            {
                ViewBag.FV = 0;
                ViewBag.FV1 = 0;
                ViewBag.FV2 = 0;
            }
            return View(model);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
