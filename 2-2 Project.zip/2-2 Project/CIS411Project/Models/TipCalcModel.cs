﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CIS411Project.Models
{
    public class TipCalcModel
    {
        [Required(ErrorMessage = "Please enter a digit between 0 and 1000.")]
        [Range(0, 1000, ErrorMessage =
                 "Enter the Cost of Meal amount, must be between 0 and 1000.")]

        public decimal? CostOfMeal { get; set; }

        public decimal? discount15()
        {

            decimal? futureValue = 0;
            decimal? tip15 = (decimal?).15;

            futureValue = (CostOfMeal * tip15);

            return futureValue;
        }
        public decimal? discount20()
        {

            decimal? futureValue = 0;
            decimal? tip20 = (decimal?).20;

            futureValue = (CostOfMeal * tip20);

            return futureValue;
        }
        public decimal? discount25()
        {

            decimal? futureValue = 0;
            decimal? tip25 = (decimal?).25;

            futureValue = (CostOfMeal * tip25);

            return futureValue;
        }
    }
}
