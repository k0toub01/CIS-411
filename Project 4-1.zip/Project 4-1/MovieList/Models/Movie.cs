﻿using System.ComponentModel.DataAnnotations;

namespace MovieList.Models
{
    public class Movie
    {
        // EF Core will configure the database to generate this value
        public int MovieId { get; set; }

        [Required(ErrorMessage = "Please enter a name.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter a Email.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your last name.")]
        public string LName { get; set; }

        [Required(ErrorMessage = "Please enter a Phone Number.")]
        [MinLength(10, ErrorMessage = "A Phone Number need 10 digits")]
        [MaxLength(10, ErrorMessage = "A Phone Number need 10 digits")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter a genre.")]
        public string GenreId { get; set; }
        public Genre Genre { get; set; }

        public string Slug =>
            Name?.Replace(' ', '-').ToLower() + '-' + LName?.ToString();
    }
}
